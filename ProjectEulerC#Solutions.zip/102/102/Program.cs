﻿using System;
using System.Diagnostics;
using System.IO;

class Problem102
{
    public static void Main(string[] args)
    {
        Stopwatch clock = Stopwatch.StartNew();

        string[] lines = File.ReadAllLines("triangle.txt");

        int result = 0;

        foreach (string line in lines)
        {
            
            string[] segments = line.Split(',');
            int[,] coordinates = new int[2, segments.Length / 2];

            int[] A = { 0, 0 };
            int[] B = { 0, 0 };
            int[] C = { 0, 0 };
            int[] P = { 0, 0 };

            if (segments.Length == 6 &&
                int.TryParse(segments[0], out A[0]) &&
                int.TryParse(segments[1], out A[1]) &&
                int.TryParse(segments[2], out B[0]) &&
                int.TryParse(segments[3], out B[1]) &&
                int.TryParse(segments[4], out C[0]) &&
                int.TryParse(segments[5], out C[1]))
            {
                if (area(A, B, C) == area(A, B, P) + area(A, P, C) + area(P, B, C))
                    result++;
            }
            else
            {
                Console.WriteLine("Непраильные данные");
            }
        }

        clock.Stop();
        Console.WriteLine("количество треугольников, внутренняя часть которых содержит начало координат: {0} ", result);
    }

    private static int area(int[] a, int[] b, int[] c)
    {
        return Math.Abs((a[0] - c[0]) * (b[1] - a[1]) - (a[0] - b[0]) * (c[1] - a[1]));
    }
}
