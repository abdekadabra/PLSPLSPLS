﻿using System;
using System.Collections.Generic;
using System.Linq;

class Program
{
    // Константы, определенные в оригинальном коде
    const int L2 = 20, L3 = 13, N = 1000000 + 1;

    // Массивы и переменные, заменяющие многомерные массивы и обычные массивы в оригинальном коде
    static int[][][] f = new int[N][][];
    static int[] g = new int[N];
    static int[] P2 = new int[L2];
    static int[] P3 = new int[L3];

    // Функция для проверки, является ли число простым
    static bool IsPrime(int x)
    {
        for (int i = 2; i * i <= x; ++i)
            if (x % i == 0) return false;
        return true;
    }

    // Основная функция программы
    static void Main(string[] args)
    {
        // Инициализация массивов и переменных
        for (int i = 0; i < N; ++i)
        {
            f[i] = new int[L2][];
            for (int j = 0; j < L2; ++j)
            {
                f[i][j] = new int[L3];
            }
        }

        for (int i = 0; i < L2; ++i)
            P2[i] = 1 << i;

        for (int i = 0; i < L3; ++i)
            P3[i] = i > 0 ? P3[i - 1] * 3 : 1;

        // Заполнение массива f
        for (int j = 0; j < L2; ++j)
        {
            for (int k = 0; k < L3; ++k)
            {
                int p = P2[j] * P3[k];
                if (p >= N) break;
                f[p][j][k] = 1;
            }
        }

        // Заполнение массивов f и g в соответствии с логикой оригинального кода
        for (int i = 1; i < N; ++i)
        {
            for (int j = 0; j < L2; ++j)
            {
                for (int k = 0; k < L3; ++k)
                {
                    if (f[i][j][k] == 0) continue;
                    g[i] += f[i][j][k];
                    for (int u = 0; u < j; ++u)
                    {
                        for (int v = k + 1; v < L3; ++v)
                        {
                            int q = i + P2[u] * P3[v];
                            if (q >= N) break;
                            f[q][u][v] += f[i][j][k];
                        }
                    }
                }
            }
        }

        // Вычисление и вывод результата
        long ans = 0;
        for (int i = 2; i < N; ++i)
        {
            if (g[i] == 1 && IsPrime(i))
                ans += i;
        }

        Console.WriteLine(ans);
    }
}
