﻿using System;
using System.Collections.Generic;

// Внутренний цикл содержит переменную под названием ''power'', которая представляет собой base^{exponent}. Затем base^{exponent+1} = base^{exponent} * base.
// Сумма цифр проходит по всем цифрам и отслеживает наибольшую сумму (''maxSum'').

// Класс BigNum представляет большие числа в виде списка целых чисел (uint).
public class BigNum : List<uint>
{
    // Максимальная цифра в числе (основание системы счисления).
    public const uint MaxDigit = 10;

    // Конструктор класса для инициализации объекта BigNum из ulong.
    public BigNum(ulong x = 0)
    {
        do
        {
            // Добавляем остаток от деления x на MaxDigit в список.
            Add((uint)(x % MaxDigit));
            // Уменьшаем x на MaxDigit, чтобы получить следующую цифру.
            x /= MaxDigit;
        } while (x > 0); // Продолжаем, пока x не станет равным 0.
    }

    // Метод для умножения текущего объекта BigNum на переданный множитель (фактор).
    public BigNum Умножить(uint factor)
    {
        ulong carry = 0; // Перенос при умножении.
        var result = new BigNum(); // Результат умножения.
        foreach (var i in this)
        {
            // Умножаем текущую цифру на множитель и прибавляем перенос.
            carry += i * factor;
            // Добавляем остаток от деления на MaxDigit к результату.
            result.Add((uint)(carry % MaxDigit));
            // Перенос - целая часть от деления на MaxDigit.
            carry /= MaxDigit;
        }
        // Пока есть перенос, добавляем его к результату.
        while (carry > 0)
        {
            result.Add((uint)(carry % MaxDigit));
            carry /= MaxDigit;
        }

        return result; // Возвращаем результат умножения.
    }
}


class Program
{

    static void Main(string[] args)
    {
        uint maximum = 100; // Максимальное значение для базы и показателя степени.

        uint maxSum = 1; // Максимальная сумма цифр в числе (изначально 1).
        for (uint baseVal = 1; baseVal <= maximum; baseVal++)
        {
            var power = new BigNum(1); // Инициализация числа степени (изначально 1).
            for (uint exponent = 1; exponent <= maximum; exponent++)
            {
                uint sum = 0; // Сумма цифр в числе степени.
                foreach (var digit in power)
                    sum += digit; // Суммируем цифры числа степени.

                if (maxSum < sum)
                    maxSum = sum; // Обновляем максимальную сумму при необходимости.

                power = power.Умножить(baseVal); // Умножаем число степени на базу.
            }
        }

        Console.WriteLine(maxSum); // Выводим максимальную сумму цифр.
    }
}
