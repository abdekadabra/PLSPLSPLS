﻿using System;

class Program
{
    // Выполнение всех ходов для всех перестановок заданного размера
    // ==> нужно только для понимания вида формулы, больше не требуется
    static double Evaluate(int size)
    {
        // данные = { 1,2,3,...,size }
        int[] data = new int[size];
        for (int i = 0; i < size; i++)
            data[i] = i + 1;

        // подсчет ходов и перестановок
        int moves = 0;
        int permutations = 0;
        do
        {
            // получаем текущую перестановку
            int[] current = new int[size];
            Array.Copy(data, current, size);
            permutations++;

            // сортируем контейнер
            int pos = 1;
            // сравниваем data[pos - 1] и data[pos]
            while (pos < size)
            {
                // пара в неправильном порядке?
                if (current[pos] < current[pos - 1])
                {
                    // поворачиваем все элементы от 0 до pos вправо один раз (последний элемент становится первым)
                    Array.Reverse(current, 0, pos + 1);
                    moves++;
                    // начинаем заново
                    pos = 1;
                }
                else
                    pos++;
            }
        } while (NextPermutation(data));

        double result = (double)moves / permutations;
        Console.WriteLine($"E({size})={result:F2} ={moves}/{permutations}");
        return result;
    }

    // Функция для генерации следующей перестановки
    static bool NextPermutation(int[] array)
    {
        int i = array.Length - 1;
        while (i > 0 && array[i - 1] >= array[i])
            i--;

        if (i <= 0)
            return false;

        int j = array.Length - 1;
        while (array[j] <= array[i - 1])
            j--;

        // Обмен array[i-1] и array[j]
        int temp = array[i - 1];
        array[i - 1] = array[j];
        array[j] = temp;

        // Обратный порядок суффикса
        j = array.Length - 1;
        while (i < j)
        {
            temp = array[i];
            array[i] = array[j];
            array[j] = temp;
            i++;
            j--;
        }

        return true;
    }

    static void Main()
    {
        int limit = 29;
        double result = 0;
        for (int i = 1; i <= limit; i++)
        {
            // 2^(i-1) - 1
            int numerator = (1 << (i - 1)) - 1; // 0,1,3,7,15,31,...
            // добавляем к результату
            result += (double)numerator / i;
        }
        Console.WriteLine($"{result:F2}");
    }
}
