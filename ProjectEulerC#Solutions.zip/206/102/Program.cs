﻿using System;

class MainClass
{
    // возвращает true, если корень^2 соответствует 1_2_3_4_5_6_7_8_9_0
    static bool Match(ulong x)
    {
        ulong square = x * x;

        // требуемые цифры в обратном порядке
        uint[] Right2Left = { 0, 9, 8, 7, 6, 5, 4, 3, 2, 1 };
        uint index = 0;

        // проверка всех цифр
        do
        {
            // самая правая цифра соответствует текущему элементу Right2Left?
            var digit = square % 10;
            if (digit != Right2Left[index++])
                return false;

            // удаляем цифру, которая прошла тест, и пропускаем следующую неизвестную цифру
            square /= 100;
        } while (square > 0);

        // все тесты пройдены!
        return true;
    }

    static void Main(string[] args)
    {
        // самое маленькое возможное число: пробелы - нули => sqrt(1020304050607080900)
        const uint MinNumber = 1010101010;
        // самое большое возможное число: пробелы - девятки => sqrt(1929394959697989990)
        const uint MaxNumber = 1389026620;

        //for (uint x = MinNumber; x <= MaxNumber; x += 10)
        for (uint x = MaxNumber; x >= MinNumber; x -= 10)
        {
            if (Match(x))
            {
                Console.WriteLine(x);
                break;
            }
        }
    }
}
